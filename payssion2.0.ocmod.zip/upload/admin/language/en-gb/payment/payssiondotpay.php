<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'Dotpay Poland';
$_['text_payssiondotpay']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/dotpay_pl.png" alt="Payssion" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';