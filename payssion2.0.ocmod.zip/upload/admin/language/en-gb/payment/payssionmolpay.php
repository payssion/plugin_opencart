<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'MOLPay (via Payssion)';
$_['text_payssionmolpay']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/molpay.png" alt="Payssion" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';