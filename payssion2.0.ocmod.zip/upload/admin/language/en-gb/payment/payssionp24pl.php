<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'Przelewy24';
$_['text_payssionp24pl']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/p24_pl.png" alt="Payssion" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';