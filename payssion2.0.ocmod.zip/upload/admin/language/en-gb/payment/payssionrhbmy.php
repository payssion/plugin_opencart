<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'RHB Now Malaysia (via Payssion)';
$_['text_payssionrhbmy']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/rhb_my.png" alt="Payssion" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';