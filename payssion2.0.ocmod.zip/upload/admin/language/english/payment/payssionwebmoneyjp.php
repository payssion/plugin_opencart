<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'WebMoney Japan (via Payssion)';
$_['text_payssionwebmoneyjp']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/webmoney_jp.png" alt="Payssion" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';