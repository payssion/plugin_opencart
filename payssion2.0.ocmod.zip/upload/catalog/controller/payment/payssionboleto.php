<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerPaymentPayssionBoleto extends ControllerPaymentPayssion {
	protected $pm_id = 'boleto_br';
}