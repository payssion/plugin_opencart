<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerPaymentPayssionOnecard extends ControllerPaymentPayssion {
	protected $pm_id = 'onecard';
}